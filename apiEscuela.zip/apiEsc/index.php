<?php

header("Location: /apiEsc/public/");
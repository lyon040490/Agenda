<?php
/**
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Application\Model\ValidaCampos;
use Application\Model\ValidaToken;


class IndexController extends AbstractActionController
{
    private $acction;

        
    public function indexAction()
    {
       
       $metodo = $this->getRequest()->getMethod();
       $data = json_decode($this->getRequest()->getContent(), true);
       $valida = new ValidaCampos();    
       if(!in_array('userToken',array_keys($data)) &&  $metodo == 'POST'){
           $valida->valida(new ValidaToken($this->params()->fromQuery()));   
       }
       
       if($metodo != 'POST'){
           $valida->valida(new ValidaToken($this->params()->fromQuery()));   
       }
       
       switch(trim($metodo)){
           case 'POST' :
               $this->acction = new \Application\Model\AccionPost();
               if(in_array('userToken',array_keys($data))){
                  $this->acction->generaToken($data);
               }else{
                  $this->acction->guardaClaificacion($data);
               }          
           break;
           case 'GET' :
               $this->acction = new \Application\Model\AccionGet();
               $this->acction->obtenerClaificacion();   
           break;
           case 'PUT' : 
               $this->acction = new \Application\Model\AccionPut();
               $this->acction->actualizaClaificacion($data);
           break;
           case 'DELETE' : 
               $this->acction = new \Application\Model\AccionDelete();
               $this->acction->borrarClaificacion($data);
           default :
               echo json_encode(array('success' => 'error', 'msg' => 'el metodo '.$metodo.' no es valido'));
           break;
       }
     
    }
}
<?php

/**
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase de metodo DELETE
 */

namespace Application\Model;

use Zend\Db\Sql\Sql;
use Application\Model\ConexionBD;
use Zend\Db\Adapter\Adapter;

class AccionDelete
{

    public function borrarClaificacion($data){ 
    $db = new ConexionBD();
    $adapter = $db->abrirConexion();
 
    $validaciones = new ValidaCampos();
    $arr =  array('DELETE' => array_keys($data)); 
    $validaciones->valida(new ValidaRequeridos($arr));
    
    $sql = new Sql($adapter);
    $delete = $sql->delete('t_calificaciones');
    $delete->where('id_t_calificaciones = '.$data['id_t_calificaciones']);
    $selectString = $sql->getSqlStringForSqlObject($delete);
    $results = $adapter->query($selectString, Adapter::QUERY_MODE_EXECUTE);
            
    echo json_encode(array("success"=>"ok", "msg"=>"calificacion eliminada"));
    
    die();
    
    }
    
}


<?php

/* 
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;

class ValidaCalificacion implements ValidaInterfaz
{
        protected $parametros;
    
    public function __construct($parametros){
        $this->parametros = $parametros;
    }
    
    public function valida(){
       if (!preg_match("/^([0-9]|[10]).([0-9])$/", $this->parametros)) {
          return array("EL campo ".$this->parametros." debe de estar en rango de 0 a 10.");
       }
    }

}
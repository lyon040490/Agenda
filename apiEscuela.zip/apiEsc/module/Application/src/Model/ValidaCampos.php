<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase para validacion de datos
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;

class ValidaCampos 
{
    protected $parametros;
    
    public function __construct($parametros){
        $db = new ConexionBD();
        $this->adaptador = $db->abrirConexion();
        $this->parametros = $parametros;
    }
    
    public function valida($estrategia){
        return $estrategia->valida($this->parametros);
        
    }
    
}
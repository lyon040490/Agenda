<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase de metodo POST
 */

namespace Application\Model;

use Zend\Db\Sql\Sql;
use Application\Model\ConexionBD;
use Zend\Db\Adapter\Adapter;
use Application\Model\ValidaCampos;
use Application\Model\ValidaCalificacion;
use Application\Model\ValidaNumerico;
use Application\Model\ValidaFecha;
use Application\Model\ValidaRequeridos;


class AccionPost
{
    protected $adaptador;
    protected $validaciones;
    
    public function __construct(){
        $db = new ConexionBD();
        $this->adaptador = $db->abrirConexion();
        $this->validaciones = new ValidaCampos();
    }

    public function guardaClaificacion($data){ 
        
    $query = "SELECT id_t_materias "
             . "FROM t_calificaciones "
            . "WHERE id_t_materias='".$data['id_t_materias']."' "
              . "AND id_t_usuarios='".$data['id_t_usuarios']."'";
    $ValCalif = $this->adaptador->query($query, Adapter::QUERY_MODE_EXECUTE)->toArray();
    if(!empty($ValCalif)){
        echo json_encode(array("success"=>"error", "msg"=>"El alumno no puede tener dos calificaciones de la misma materia")); 
        die();
    }
    
    $arr =  array('POST' => array_keys($data)); 
    $this->validaciones->valida(new ValidaRequeridos(array('POST' => array_keys($data)))); 
    $validaciones = array();
    array_push($validaciones,$this->validaciones->valida(new ValidaFecha($data['fecha_registro']))[0]); 
    array_push($validaciones,$this->validaciones->Valida(new ValidaNumerico($data['id_t_materias']))[0]); 
    array_push($validaciones,$this->validaciones->Valida(new ValidaNumerico($data['id_t_usuarios']))[0]); 
    array_push($validaciones,$this->validaciones->valida(new ValidaCalificacion($data['calificacion']))[0]); 
        if(!empty($validaciones)){
        echo json_encode(array("success"=>"error", "msg"=>"Los campos no cumplen el formato requerido", "errores" => array_filter($validaciones))); 
        die();
    }
    
    $sql = new Sql($this->adaptador);
    $insert = $sql->insert('t_calificaciones');
    $newData = array(
        'id_t_materias'=> $data['id_t_materias'],
        'id_t_usuarios'=> $data['id_t_usuarios'],
        'calificacion'=> $data['calificacion'],
        'fecha_registro'=> $data['fecha_registro']
    );
    $insert->values($newData);
    $selectString = $sql->getSqlStringForSqlObject($insert);
    $this->adaptador->query($selectString, Adapter::QUERY_MODE_EXECUTE);            
    echo json_encode(array("success"=>"ok", "msg"=>"calificacion registrada"));
    die();
    
    }
    
    public function generaToken($user){
        $key = 'escuelaapiKey';
        
        $query = "SELECT nombre_usuario"
                     . ",contrasenia"
                     . ",token "
                 . "FROM t_usuarios_api "
                . "WHERE nombre_usuario='".$user['userToken']."'";
        $rows = $this->adaptador->query($query,Adapter::QUERY_MODE_EXECUTE)->toArray();
        
        if(md5($user['passToken']) == $rows[0]['contrasenia']){
            
            $md5 = (md5($user['userToken'].date('Y-m-dH:i:s')));
            $passEncrypt = hash('sha256', $key.$md5);
            
            $queryUp = "UPDATE t_usuarios_api "
                        . "SET token='".$passEncrypt."' "
                      . "WHERE nombre_usuario='".$user['userToken']."'";
            $rows = $this->adaptador->query($queryUp,Adapter::QUERY_MODE_EXECUTE);

            echo json_encode(array('token' => $passEncrypt));
            die();
        
        }else{
            echo json_encode(array("success"=>"error", "msg"=>"El usuario o contraseña es incorrecta")); 
            die();
        }
        
    }
}
<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase de metodo PUT
 */

namespace Application\Model;

use Zend\Db\Sql\Sql;
use Application\Model\ConexionBD;
use Zend\Db\Adapter\Adapter;

class AccionPut
{

    public function actualizaClaificacion($data){ 
    $db = new ConexionBD();
    $adapter = $db->abrirConexion();
    
    $validaciones = new ValidaCampos();
    $arr =  array('DELETE' => array_keys($data)); 
    $validaciones->valida(new ValidaRequeridos($arr));
    
    $sql = new Sql($adapter);
    $newData = array(
        'id_t_materias'=> $data['id_t_materias'],
        'id_t_usuarios'=> $data['id_t_usuarios'],
        'calificacion'=> $data['calificacion'],
        'fecha_registro'=> $data['fecha_registro']
    );
    
    $update = $sql->update('t_calificaciones');
    $update->set($newData);
    $update->where('id_t_calificaciones = '.$data['id_t_calificaciones']);
    $selectString = $sql->getSqlStringForSqlObject($update);
    $results = $adapter->query($selectString, Adapter::QUERY_MODE_EXECUTE);
            
    echo json_encode(array("success"=>"ok", "msg"=>"calificacion actualizada"));
    
    die();
        
    }
    
}


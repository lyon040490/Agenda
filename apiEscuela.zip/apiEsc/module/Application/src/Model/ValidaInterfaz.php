<?php

/*
 */

namespace Application\Model;

interface ValidaInterfaz 
{

public function valida();
    
}

<?php

/*
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase de metodo GET
 */

namespace Application\Model;

use Zend\Db\Sql\Sql;
use Application\Model\ConexionBD;
use Zend\Db\Adapter\Adapter;

class AccionGet
{

    public function obtenerClaificacion(){
        
    $db = new ConexionBD();
    $adapter = $db->abrirConexion();
    

    $query = "select ta.id_t_usuarios
             	    ,ta.nombre
                    ,ta.ap_paterno
                    ,ta.ap_materno
                    ,tm.nombre
                    ,tc.calificacion
                    ,DATE_FORMAT(tc.fecha_registro,'%d/%m/%Y') as fecha_registro
             from t_alumnos ta
             join t_calificaciones tc 
               on tc.id_t_usuarios = ta.id_t_usuarios
             join t_materias tm 
               on tc.id_t_materias = tm.id_t_materias";

    try {
       $rows = $adapter->query($query,Adapter::QUERY_MODE_EXECUTE);  // $query
    } catch (Exception $ex) {
       echo $ex;
    }

    $sum = array_sum(array_column($rows->toArray(),'calificacion'));
    $count = count(array_column($rows->toArray(),'calificacion'));
    $promedio = number_format((intval($sum)/intval($count)),2);
    
    $data = $rows->toArray();
    $data[$count] = array('promedio' =>$promedio);
    
    echo json_encode($data);

    }
    
}


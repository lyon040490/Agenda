<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase para validacion de datos de Fecha
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;

class ValidaFecha implements ValidaInterfaz
{
    protected $parametros;
    
    public function __construct($parametros){
        $db = new ConexionBD();
        $this->adaptador = $db->abrirConexion();
        $this->parametros = $parametros;
    }
    
    public function valida(){
       if (!preg_match("/^([0-9][0-9][0-9][0-9])-([0][1-9]|[1][1-2])-([0-2][0-9]|[3][0-1])$/", $this->parametros)) {
          return array("EL campo ".$this->parametros." no cumple con el formato de fecha requerido yyyy-dd-mm.");
       }
    }
}
<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase que abre la conexion a base de datos
 */

namespace Application\Model;

use Zend\Db\Adapter\Adapter;

class ConexionBD
{
    
    private $config = [
                      'driver'   => 'Mysqli',
                      'database' => 'escuela',
                      'username' => 'root',
                      'password' => 'abcd1234',
                      ];

    public function abrirConexion(){
        
        $adapter = new Adapter($this->config);
        return $adapter;
    
    }
    
}
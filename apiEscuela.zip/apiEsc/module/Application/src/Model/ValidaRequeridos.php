<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase para validacion de campos requeridos
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;

class ValidaRequeridos implements ValidaInterfaz
{
    protected $parametros;
    
    public function __construct($parametros){
        $this->parametros = $parametros;
    }
    
    public function valida(){
        
        $diferentes = array();
        $metodo = array_keys($this->parametros)[0];
        switch($metodo){
           case 'POST' :
               $RequeridosPost = array('id_t_materias'
                                      ,'id_t_usuarios'
                                      ,'calificacion'
                                      ,'fecha_registro');
               $diferentes = array_diff($RequeridosPost, $this->parametros['POST']);
           break;
           case 'PUT' :
               $RequeridosPost = array('id_t_materias'
                                      ,'id_t_usuarios'
                                      ,'calificacion'
                                      ,'fecha_registro'
                                      ,'id_t_calificaciones');
               $diferentes = array_diff($RequeridosPost, $this->parametros['POST']);
           break;
           case 'DELETE' :
               $RequeridosPost = array('id_t_calificaciones');
           break; 
        }
        
        foreach($RequeridosPost as $llave => $val){
            if((!in_array($val, $this->parametros[$metodo]))){
                array_push($diferentes,$val);
            }
        }

        if(!empty($diferentes)){   
           echo json_encode(array("success"=>"error", "msg"=>"La trama no es correcta", "faltantes" => implode($diferentes,','))); 
           die();
        }
   
    }

}

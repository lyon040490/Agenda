<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase para validacion de token
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;
use Zend\Db\Sql\Sql;
use Application\Model\ConexionBD;
use Zend\Db\Adapter\Adapter;

class ValidaToken implements ValidaInterfaz
{
    protected $adaptador;
    protected $parametros;
    
    public function __construct($parametros){
        $db = new ConexionBD();
        $this->adaptador = $db->abrirConexion();
        $this->parametros = $parametros;
    }
    
    public function valida(){
        $query = "SELECT nombre_usuario"
                     . ",contrasenia"
                     . ",token "
                 . "FROM t_usuarios_api "
                . "WHERE nombre_usuario='".$this->parametros['usuario']."'";
        $rows = $this->adaptador->query($query,Adapter::QUERY_MODE_EXECUTE)->toArray();
        
        if(!$this->parametros['token'] || !$this->parametros['usuario']){
            echo json_encode(array("success"=>"error", "msg"=>"El usuario o token son obligatorios")); 
            die();
        }
        
        if($rows[0]['token'] != $this->parametros['token']){
            echo json_encode(array("success"=>"error", "msg"=>"El usuario o token es incorrecto")); 
            die();
        }
        
    }

}
<?php

/* 
 * Autor: Leonardo Velaquez Garcia
 * Fecha de creacion: 10/01/2018
 * Clase para validacion de datos Alfanumericos
 */

namespace Application\Model;

use Application\Model\ValidaInterfaz;

class ValidaAlfanumerico implements ValidaInterfaz
{
        protected $parametros;
    
    public function __construct($parametros){
        $this->parametros = $parametros;
    }
    
    public function valida(){
       if (!preg_match("/^\w+$/", $this->parametros)) {
          return array("EL campo ".$this->parametros." debe ser alfanumerico.");
       }
    }

}